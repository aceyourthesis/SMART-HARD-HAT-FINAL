        <section id="footer">
            <div class="container text-center">
                <p>Cavite State University - Indang Campus</p>
            </div>
        </section>
    </body>
</html>