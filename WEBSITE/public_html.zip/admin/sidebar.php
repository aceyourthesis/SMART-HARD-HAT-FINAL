<style>
  .main-sidebar a{
  color:white !important;
}
</style>
<aside class="main-sidebar">
  <section class="sidebar">
    <ul class="sidebar-menu" data-widget="tree">
      <li style="text-align: center;padding: 20px;display: flex;place-items: center;"><div style="text-align: left;font-size: 18px;font-weight: bold;color: #fff;padding-left: 5px;">Hard Hat Data</div></li>

      <li><a href="dashboard.php"><i class="fas fa-calendar"></i> <span>Dashboard</span></a></li>
      <li><a href="../logout.php"><i class="fas fa-sign-out"></i> <span>Logout</span></a></li>

    </ul>
  </section>
</aside>